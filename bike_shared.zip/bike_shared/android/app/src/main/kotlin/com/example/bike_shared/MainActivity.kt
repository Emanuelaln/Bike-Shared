package com.example.bike_shared

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
